import requests

# Define your API key
api_key = 'fmoBsARtgdmbeNW93wph42Rt'

# Specify the image file path
image_path = '2093.jpg'

# Make a request to remove.bg API
response = requests.post(
    'https://api.remove.bg/v1.0/removebg',
    files={'image_file': open(image_path, 'rb')},
    data={'size': 'auto'},
    headers={'X-Api-Key': api_key},
)

# Save the resulting image
with open('output.png', 'wb') as out:
    out.write(response.content)

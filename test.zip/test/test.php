
<?php
// URL of the PDF file on the other website
$pdf_url = 'https://dna3.dnalinks.in/pricelist/fancyhphtcvd.pdf';

// Get the PDF content from the remote URL
$pdf_content = file_get_contents($pdf_url);

if ($pdf_content === false) {
    die('Failed to fetch the PDF.');
}

// Set the appropriate headers for the PDF download
header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="downloaded-file.pdf"');

// Output the PDF content to the user for download
echo $pdf_content;
?>
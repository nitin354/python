<!DOCTYPE html>
<html>
<head>
    <title>Run Python Script on Click</title>
</head>
<body>
    <form action="" method="post">
        <input type="submit" name="submit" value="Run Python Script">
    </form>
</body>
</html>
<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Execute the Python script
    $output = shell_exec('python videocap.py');
    echo "<pre>$output</pre>";
}
?>
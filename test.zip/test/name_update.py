#!/usr/bin/env python3

import mysql.connector
from mysql.connector import Error
import requests






def db_connect():
    try:
        connection = mysql.connector.connect(host='localhost',
                                         database='showcase-engagement',
                                         user='root',
                                         password='')

        if connection.is_connected():
            db_Info = connection.get_server_info()
            print("Connected to MySQL Server version ", db_Info)
            cursor = connection.cursor()
            return connection

    except Error as e:
        print("Error while connecting to MySQL", e)

def change_name():
    connection = db_connect()
    cursor = connection.cursor()

    select_product = "SELECT product_id,metal_color,shape,category_id from products Where `brand_id` = 1"
    cursor.execute(select_product)
    result = cursor.fetchall()

    line_count = 0
    for x in result:
        

        shape=""
        line_count += 1
        product_id = x[0]
        metal_color = str(x[1]).replace("-"," ")
        if x[2]:
            shape = str(x[2])
        category_id = x[3]
        
        select_style = "SELECT attribute_id FROM `attribute` WHERE `category_id` = '"+str(category_id)+"' and  `name` LIKE 'style%'"
        cursor.execute(select_style)
        attribute_id = cursor.fetchone()
        attribute_id=str(attribute_id[0])
        
        select_category = "SELECT name FROM `category` WHERE `category_id` = '"+str(category_id)+"'"
        cursor.execute(select_category)
        category_name = cursor.fetchone()
        category_name=str(category_name[0])
        
        select_attribute = "SELECT value FROM `attribute_value` WHERE  attribute_id='"+str(attribute_id)+"' and `product_id` = '"+str(product_id)+"'"
        #print(select_attribute)
        cursor.execute(select_attribute)
        attribute_result = cursor.fetchone()
        
        style=str(attribute_result[0])
        
        if shape:
            name = metal_color+" "+style+" "+shape+" "+category_name
        else:
            name = metal_color+" "+style+" "+category_name
            
        name = name.title()
        #print(product_id)
        #print(name)
        print(line_count)
        update_product = "UPDATE products SET name = '"+name+"' WHERE product_id='"+str(product_id)+"'"
        cursor.execute(update_product)
        connection.commit()
        
change_name()

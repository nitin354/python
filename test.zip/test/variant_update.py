#!/usr/bin/env python3

import mysql.connector
from mysql.connector import Error
import requests






def db_connect():
    try:
        connection = mysql.connector.connect(host='localhost',
                                         database='showcase-engagement',
                                         user='root',
                                         password='')

        if connection.is_connected():
            db_Info = connection.get_server_info()
            print("Connected to MySQL Server version ", db_Info)
            cursor = connection.cursor()
            return connection

    except Error as e:
        print("Error while connecting to MySQL", e)

def check_image():
    connection = db_connect()
    cursor = connection.cursor()

    select_product = "SELECT sku,product_id from products Where category_id = 2 AND `brand_id` = 1"
    cursor.execute(select_product)
    result = cursor.fetchall()

    line_count = 0
    for x in result:
        
        

        line_count += 1
        product_id = x[1]
        sku = x[0].split('-')

        variant = sku[0]+"-ER"

        print(variant);
        print(line_count);
        update_product = "UPDATE products SET variant_id = '"+variant+"' WHERE product_id='"+str(product_id)+"'"
        cursor.execute(update_product)
        connection.commit()
        
        # line_count += 1
        # image_url = x[1]
        # media_id = str(x[0])
        # r = requests.get(image_url, verify=True, timeout=20)       
        # print(image_url, media_id)  
        # print(r.status_code, line_count) 
   
        # if(r.status_code != 200):
        #     #print(image_url, media_id)
        #     #print(r.status_code)
        #     delete_product = "UPDATE media SET check_image = 2 WHERE media_id='"+media_id+"'"
        #     cursor.execute(delete_product)
        #     connection.commit() 
        # else :
            # update_product = "UPDATE media SET check_image = 1 WHERE media_id='"+media_id+"'"
            # cursor.execute(update_product)
            # connection.commit()     


check_image()

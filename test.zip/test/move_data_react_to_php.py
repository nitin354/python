import mysql.connector
from mysql.connector import Error


def old_db_connect():
    try:

        old_connection = mysql.connector.connect(host='localhost',
                                         database='showcase-new',
                                         user='root',
                                         password='')

        if old_connection.is_connected():
            db_Info = old_connection.get_server_info()
            print("Connected Old DB")
            cursor = old_connection.cursor()
            return old_connection

    except Error as e:
        print("Error while connecting to MySQL", e)
		
def new_db_connect():
    try:

        new_connection = mysql.connector.connect(host='localhost',
                                         database='cultured',
                                         user='root',
                                         password='')

        if new_connection.is_connected():
            db_Info = new_connection.get_server_info()
            print("Connected New DB")
            cursor = new_connection.cursor()
            return new_connection

    except Error as e:
        print("Error while connecting to MySQL", e)

def process_moving_data():

    #connect to old database
    old_connection = old_db_connect()
    old_cursor = old_connection.cursor()
    #connect to new database
    new_connection = new_db_connect()
    new_cursor = new_connection.cursor()
    sql_select_Query = "SELECT * FROM `products` WHERE product_id in (SELECT product_id FROM `attribute_value` WHERE `attribute_id` = 2050 AND `value` LIKE '%LAB GROWN%') and brand_id=1 and category_id=8"
    old_cursor.execute(sql_select_Query)
    # get all records
    records = old_cursor.fetchall()
    print("Total number of rows in table: ", old_cursor.rowcount)  
    count=0
    for row in records:
        count += 1
        print(count)
        old_pid = row[0] 
        #insert product
        # insert_product = "INSERT INTO products (`gender`, `name`, `slug`, `sku`, `variant_id`, `category_id`, `brand_id`, `metal_color`, `shape`, `setwithmin`, `setwithmax`, `ring_sizes`, `description`, `short_desc`, `cost_price`, `price`, `discount`, `sale_price`, `enable_ecommerce`, `enable_engraving`, `meta_title`, `meta_keywords`, `meta_desp`, `status`, `is_gift`) VALUES ( %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"

        insert_product = "INSERT INTO products (`gender`, `name`, `slug`, `sku`,`fake_sku`, `group_id`,`gem_group_id`,`gem_id`, `category_id`, `brand_id`, `metal_color`, `default_shape`, `sizes`, `desp`, `short`, `cost_price`, `price`, `discount`, `sale_price`, `enable_ecommerce`, `enable_engraving`, `meta_title`, `meta_keywords`, `meta_desp`, `status`,`product_url`,`price_url`) VALUES ( %s,%s,%s,%s,%s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"

        # setwithmin=shape_data[0]
        # setwithmax=shape_data[1]
        # print(row[27])
        status="inactive"
        if row[25] == 1:
            status="active"


        val_product = (row[1], row[2], row[3], row[4],row[4], row[5],row[5],5, row[6], row[7], row[8], row[9], row[12], row[13], row[14], row[15], row[16], row[17],row[18], row[20], row[21], row[22], row[23], row[23],status,row[27],row[28])
        # print(val_product)
        # exit(0)

        try:
            new_cursor.execute(insert_product, val_product)
            new_connection.commit()
        except mysql.connector.Error as error:
            print("Failed to insert record into products table {}".format(error))
            return False

        #recent insert id
        new_pid = new_cursor.lastrowid
        # print(new_pid)
        
        select_media = "SELECT * FROM `media` WHERE  check_image=1 and `product_id` = '"+str(old_pid)+"'"
        old_cursor.execute(select_media)
        media_result = old_cursor.fetchall()
        for media in media_result:
            #print(media)
            insert_media = "INSERT INTO media ( element_id, type, url, sort_order,slug,metal_type,shape,gemstone,check_image,element_type) VALUES (%s,%s,%s,%s,%s,%s, %s, %s, %s, %s)"
            media_val = (new_pid, media[2], media[3], media[4],row[3],row[8],row[9],'', media[5],'product')
            new_cursor.execute(insert_media, media_val)
            new_connection.commit()


        # attribute
        select_attribute = "SELECT * FROM `attribute_value` WHERE `product_id` = '"+str(old_pid)+"'"
        old_cursor.execute(select_attribute)
        attribute_result = old_cursor.fetchall()
        for attribute in attribute_result:
            #print(attribute)
            insert_attribute = "INSERT INTO attribute_value (product_id,attribute_id,attribute,value,group_id) VALUES (%s,%s,%s, %s, %s)"
            attribute_val = (new_pid, int(attribute[2]),'',attribute[3],row[5])
            new_cursor.execute(insert_attribute, attribute_val)
            new_connection.commit()	

        # insert_media = "INSERT INTO ring_shapes ( shape, carat, product_id, sku) VALUES (%s,%s, %s, %s)"
        # media_val = (row[9], "0.02-8.00", new_pid, row[4])
        # new_cursor.execute(insert_media, media_val)
        # new_connection.commit()	

        
    print('------------------------------------------')
    print('Processed all records.')


process_moving_data()
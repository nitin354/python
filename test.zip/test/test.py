import cv2

# Load the image
image_path = '2093.jpg'
image = cv2.imread(image_path)


# Get the dimensions (width and height) of the image
height, width, _ = image.shape
print(f"Width: {width} pixels")
print(f"Height: {height} pixels")
# Define the coordinates for cropping (top-left and bottom-right)
# Format: (start_row, start_col, end_row, end_col)
start_row = 50
start_col = 50
end_row = 200
end_col = 200

# Crop the image
cropped_image = image[start_row:end_row, start_col:end_col]

# Display the original and cropped images
cv2.imshow('Original Image', image)
cv2.imshow('Cropped Image', cropped_image)

# Wait for a key event and close the windows
cv2.waitKey(0)
cv2.destroyAllWindows()

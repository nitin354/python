<!DOCTYPE html>
<html>
<head>
    <title>Copy Content from PDF</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.11.332/pdf.js"></script>
</head>
<body>
    <button id="copyButton">Copy Content</button>

    <script>
        document.getElementById('copyButton').addEventListener('click', function() {
            // URL of the source PDF file
            var sourcePdfUrl = 'https://dna3.dnalinks.in/pricelist/fancyhphtcvd.pdf';

            // Load source PDF using pdf.js
            pdfjsLib.getDocument({ url: sourcePdfUrl }).promise
                .then(sourcePdf => {
                         // Extract text from source PDF
                        return sourcePdf.getPage(1).then(page => {
                          return page.getTextContent();
                        }).then(textContent => {
                          // Modify destination PDF
                          const destPage = destPdf.getPage(1);
                          // Insert text content into destPage
                          // ...

                          // Save the modified destination PDF
                          return destPdf.save().then(data => {
                            // Create a Blob and initiate download
                            const blob = new Blob([data], { type: 'application/pdf' });
                            const url = window.URL.createObjectURL(blob);
                            const a = document.createElement('a');
                            a.href = url;
                            a.download = 'modified.pdf';
                            document.body.appendChild(a);
                            a.click();
                            window.URL.revokeObjectURL(url);
                          });
                        });
                    console.log('Content copied from PDF and modified.');
                })
                .catch(error => {
                    console.error('Error:', error);
                });
        });
    </script>
</body>
</html>



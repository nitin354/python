import mysql.connector
from mysql.connector import Error


def old_db_connect():
    try:

        old_connection = mysql.connector.connect(host='localhost',
                                         database='showcase-new',
                                         user='root',
                                         password='')

        if old_connection.is_connected():
            db_Info = old_connection.get_server_info()
            print("Connected Old DB")
            cursor = old_connection.cursor()
            return old_connection

    except Error as e:
        print("Error while connecting to MySQL", e)
		
def new_db_connect():
    try:

        new_connection = mysql.connector.connect(host='localhost',
                                         database='declement',
                                         user='root',
                                         password='')

        if new_connection.is_connected():
            db_Info = new_connection.get_server_info()
            print("Connected New DB")
            cursor = new_connection.cursor()
            return new_connection

    except Error as e:
        print("Error while connecting to MySQL", e)

def process_moving_data():

    #connect to old database
    old_connection = old_db_connect()
    old_cursor = old_connection.cursor()
    #connect to new database
    new_connection = new_db_connect()
    new_cursor = new_connection.cursor()
    sql_select_Query = "SELECT * FROM `products` WHERE category_id=8 and status=1 and product_id in (SELECT product_id FROM `attribute_value` WHERE `value` LIKE '%LAB GROWN%' and attribute_id=2050)"
    old_cursor.execute(sql_select_Query)
    # get all records
    records = old_cursor.fetchall()
    print("Total number of rows in table: ", old_cursor.rowcount)  
    count=0
    for row in records:
        count += 1
        print(count)
        old_pid = row[0]
        #insert product
        insert_product = "INSERT INTO products (`gender`, `name`, `slug`, `sku`, `variant_id`, `category_id`, `brand_id`, `metal_color`, `shape`, `setwithmin`, `setwithmax`, `ring_sizes`, `description`, `short_desc`, `cost_price`, `price`, `discount`, `sale_price`,`markup`, `enable_ecommerce`, `enable_engraving`, `meta_title`, `meta_keywords`, `meta_desp`, `status`, `is_gift`,`product_url`,`price_url`) VALUES (%s,%s, %s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"
        
        # gender = row[1]
        # name = row[2]
        # slug = row[3]
        # sku = row[4]
        # variant_id = row[5]
        # category_id = row[6]
        # brand_id = row[7]
        # metal_color = row[8]
        # shape = row[9]
        # setwithmin = row[10]
        # setwithmax = row[11]
        # ring_sizes = row[12]
        # description = row[13]
        # short_desc = row[14]
        # cost_price = row[15]
        # price = row[16]
        # discount = row[17]
        # sale_price = row[18]
        # enable_ecommerce = row[20]
        # enable_engraving = row[21]
        # meta_title = row[22]
        # meta_keywords = row[23]
        # meta_desp = row[24]
        # status = row[25]
        # is_gift = row[26]
        # product_url = row[27]
        # price_url = row[28]
        # setwithmin=shape_data[0]
        # setwithmax=shape_data[1]
          
        # status=0
        # if row[27] == 'active':
        #     status=1
        
        #print(enable_ecommerce)

        val_product = (row[1], row[2], row[3], row[4], row[5], row[6], row[7], row[8], row[9], row[10], row[11], row[12], row[13], row[14], row[15], row[16], row[17],row[18],'2.50', row[20], row[21], row[22], row[23],row[24],row[25],row[26] ,row[27],row[28])
        #print(val_product)

  

        try:
            new_cursor.execute(insert_product, val_product)
            new_connection.commit()
        except mysql.connector.Error as error:
            print("Failed to insert record into products table {}".format(error))
            return False

        #recent insert id
        new_pid = new_cursor.lastrowid
        #print(new_pid)
        
        select_media = "SELECT * FROM `media` WHERE check_image=1 and `product_id` = '"+str(old_pid)+"'"
        old_cursor.execute(select_media)
        media_result = old_cursor.fetchall()
        for media in media_result:
            #print(media)
            insert_media = "INSERT INTO media ( product_id, type, url, sort_order) VALUES (%s, %s, %s, %s)"
            media_val = (new_pid, media[2], media[3], media[4])
            new_cursor.execute(insert_media, media_val)
            new_connection.commit()


        # attribute
        select_attribute = "SELECT * FROM `attribute_value` WHERE `product_id` = '"+str(old_pid)+"'"
        old_cursor.execute(select_attribute)
        attribute_result = old_cursor.fetchall()
        for attribute in attribute_result:
            #print(attribute)
            insert_attribute = "INSERT INTO attribute_value (product_id,attribute_id,value,status) VALUES (%s, %s, %s, %s)"
            attribute_val = (new_pid, int(attribute[2]), attribute[3], 1)
            new_cursor.execute(insert_attribute, attribute_val)
            new_connection.commit()		

        
    print('------------------------------------------')
    print('Processed all records.')


process_moving_data()
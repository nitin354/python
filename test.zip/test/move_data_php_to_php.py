import mysql.connector
from mysql.connector import Error

def old_db_connect():
    try:

        old_connection = mysql.connector.connect(host='localhost',
                                         database='demobw',
                                         user='root',
                                         password='')

        if old_connection.is_connected():
            db_Info = old_connection.get_server_info()
            print("Connected Old DB")
            cursor = old_connection.cursor()
            return old_connection

    except Error as e:
        print("Error while connecting to MySQL", e)
		
def new_db_connect():
    try:

        new_connection = mysql.connector.connect(host='localhost',
                                         database='backend2',
                                         user='root',
                                         password='')

        if new_connection.is_connected():
            db_Info = new_connection.get_server_info()
            print("Connected New DB")
            cursor = new_connection.cursor()
            return new_connection

    except Error as e:
        print("Error while connecting to MySQL", e)

def process_moving_data():

    #connect to old database
    old_connection = old_db_connect()
    old_cursor = old_connection.cursor()
    #connect to new database
    new_connection = new_db_connect()
    new_cursor = new_connection.cursor()
    sql_select_Query = "SELECT * FROM `products` WHERE `category_id` = 14 AND `brand_id` IN (2,3,4,5)"
    old_cursor.execute(sql_select_Query)
    # get all records
    records = old_cursor.fetchall()
    print("Total number of rows in table: ", old_cursor.rowcount)  
    count=0
    for row in records:
        count += 1
        print(count)
        old_pid = row[0]
        #insert product
        # insert_product = "INSERT INTO products (`gender`, `name`, `slug`, `sku`, `variant_id`, `category_id`, `brand_id`, `metal_color`, `shape`, `setwithmin`, `setwithmax`, `ring_sizes`, `description`, `short_desc`, `cost_price`, `price`, `discount`, `sale_price`, `enable_ecommerce`, `enable_engraving`, `meta_title`, `meta_keywords`, `meta_desp`, `status`, `is_gift`) VALUES ( %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"

        insert_product = "INSERT INTO products (`gender`, `name`, `slug`, `sku`,`fake_sku`, `group_id`,`gem_group_id`,`gem_id`, `category_id`, `brand_id`, `metal_color`, `default_shape`, `sizes`, `desp`, `short`, `cost_price`, `price`, `discount`, `sale_price`, `status`, `enable_engraving`, `meta_title`, `meta_keywords`, `meta_desp`) VALUES (%s,%s,%s,%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)"

        # setwithmin=shape_data[0]
        # setwithmax=shape_data[1]
        gender = row[1]
        category_id  = row[2]
        vendor_id = row[3]
        brand_id  = row[4]
        group_id  = row[5]
        gem_group_id  = row[6]
        gem_id  = row[7]
        gemstone = row[8]
        default_shape  = row[9]
        shapes  = row[10]
        metal_carat_weight = row[11]
        sizes = row[12]
        name  = row[13]
        metal_color  = row[14]
        sku  = row[15]
        fake_sku = row[16]
        desp = row[17]
        short = row[18]
        stones = row[19]
        discount = row[20]
        cost_price = row[21]
        price  = row[22]
        sale_price  = row[23]
        enable_ecommerce = row[24]
        enable_engraving = row[25]
        variant_id = row[26]
        status  = row[27]
        slug  = row[28]
        meta_title  = row[29]
        meta_keywords = row[30]
        meta_desp = row[31]
        ounce = row[32]
        is_instashop = row[33]
        updated_at = row[34]
        markup_1x_price = row[35]
        enable_price = row[36]

        # print(row)
        # status="inactive"
        # if row[25] == 1:
        #     status="active"

        val_product = (gender, name,slug, sku,fake_sku, group_id,gem_group_id,gem_id, category_id, brand_id, metal_color, default_shape, sizes, desp, short, cost_price, price, discount, sale_price, status, enable_engraving, meta_title, meta_keywords, meta_desp)
        #print(val_product)
        # exit(0)

        try:
            new_cursor.execute(insert_product, val_product)
            new_connection.commit()
        except mysql.connector.Error as error:
            print("Failed to insert record into products table {}".format(error))
            return False

        #recent insert id
        new_pid = new_cursor.lastrowid
        #print(new_pid)
        
        select_media = "SELECT * FROM `media` WHERE  `element_id` = '"+str(old_pid)+"'"
        old_cursor.execute(select_media)
        media_result = old_cursor.fetchall()
        #print(media_result)
        for media in media_result:
            #print(media)
            insert_media = "INSERT INTO media ( element_id, type, url, sort_order,slug,metal_type,shape,gemstone,check_image,element_type) VALUES (%s,%s,%s,%s,%s,%s, %s, %s, %s, %s)"
            media_val = (new_pid,media[3], media[4], media[9], media[7],metal_color,default_shape,gemstone,'','product')
            new_cursor.execute(insert_media, media_val)
            new_connection.commit()


        # attribute
        select_attribute = "SELECT * FROM `attribute_value` WHERE `product_id` = '"+str(old_pid)+"'"
        old_cursor.execute(select_attribute)
        attribute_result = old_cursor.fetchall()
        #print(attribute_result)
        for attribute in attribute_result:
            #print(attribute)
            insert_attribute = "INSERT INTO attribute_value (product_id,attribute_id,attribute,value,group_id) VALUES (%s,%s,%s, %s, %s)"
            attribute_val = (new_pid, int(attribute[3])+1000,attribute[4],attribute[1],row[5])
            new_cursor.execute(insert_attribute, attribute_val)
            new_connection.commit()	

        insert_media = "INSERT INTO ring_shapes ( shape, carat, product_id, sku) VALUES (%s,%s, %s, %s)"
        media_val = (default_shape, "0.02-8.00", new_pid, sku)
        new_cursor.execute(insert_media, media_val)
        new_connection.commit()	

        
    print('------------------------------------------')
    print('Processed all records.')


process_moving_data()
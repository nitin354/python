#!/usr/bin/env python3
import csv
import mysql.connector
filename = 'export_products.csv'
connection = mysql.connector.connect(host='localhost',
                                         database='showcase',
                                         user='proot',
                                         password='php#2020@wEbnEt')
if connection.is_connected():
    db_Info = connection.get_server_info()
    print("Connected to MySQL Server version ", db_Info)
    cursor = connection.cursor()
    cursor.execute("select database();")
    record = cursor.fetchone()
    print("You're connected to database: ", record)
	

def process_data():

    #connect to database
    sql_select_Query = "SELECT * FROM `products` where brand_id=1 and category_id=4"
    cursor.execute(sql_select_Query)
    # get all records
    records = cursor.fetchall()
    print("Total number of rows in table: ", cursor.rowcount)  
    count=0
    quotes=[]
    #attri=['product_id','gender','category_id','vendor_id','brand_id','group_id','gem_group_id','gem_id','gemstone','default_shape','shapes','metal_carat_weight','sizes','name','metal_color','sku','fake_sku','desp','short_desp','short','stones','discount','cost_price','price','sale_price','enable_ecommerce','enable_engraving','variant_id','status','slug','meta_title','meta_keywords','meta_desp','ounce','updated_at','video','image1','image2','image3','image4','image5','image6','image7','image8','image9','image10','image11','image12','image13','image14','image15','image16','image17']
    attri=['product_id','gender','category','brand','group_id','default_shape','setwithmin','setwithmax','sizes','name','metal_color','sku','desp','short_desp','discount','cost_price','price','sale_price','enable_ecommerce','enable_engraving','status','slug','meta_title','meta_keywords','meta_desp','video','image1','image2','image3','image4','image5','image6','image7','image8','image9','image10','image11','image12','image13','image14','image15']
    for row in records:
        count += 1
        print(count)
        #print(row)
        quote = {} 
        quote['product_id'] = row[0]
        quote['gender'] = row[1]
        quote['setwithmin'] = row[10]
        quote['setwithmax'] = row[11]

        quote['category'] = row[6]
        select_cat = "SELECT * FROM `category` WHERE `category_id` = '"+str(row[6])+"'"
        cursor.execute(select_cat)
        cat_result = cursor.fetchall()
        for cat in cat_result:
            quote['category'] = cat[2]

        quote['brand'] = row[7]
        select_brand = "SELECT * FROM `brands` WHERE `brand_id` = '"+str(row[7])+"'"
        cursor.execute(select_brand)
        brand_result = cursor.fetchall()
        for brand in brand_result:
            quote['brand'] = brand[1]

        
        #quote['vendor_id'] = row[3]
        quote['group_id'] = row[5]
        # quote['gem_group_id'] = row[6]
        # quote['gem_id'] = row[7]
        # quote['gemstone'] = row[8]
        quote['default_shape'] = row[9]
        # quote['shapes'] = row[10]
        # quote['metal_carat_weight'] = row[11]
        quote['sizes'] = row[12]
        quote['name'] = row[2]
        quote['metal_color'] = row[8]
        quote['sku'] = row[4]
        # quote['fake_sku'] = row[16]
        quote['desp'] = row[13]
        quote['short_desp'] = row[14]
        # quote['short'] = row[19]
        # quote['stones'] = row[20]
        quote['discount'] = row[17]
        quote['cost_price'] = row[15]
        quote['price'] = row[16]
        quote['sale_price'] = row[18]
        quote['enable_ecommerce'] = row[20]
        quote['enable_engraving'] = row[21]
        # quote['variant_id'] = row[27]
        quote['status'] = row[25]
        quote['slug'] = row[3]
        quote['meta_title'] = row[22]
        quote['meta_keywords'] = row[23]
        quote['meta_desp'] = row[24]
        # quote['ounce'] = row[33]
        # quote['updated_at'] = row[34]


   
        select_media = "SELECT * FROM `media` WHERE `product_id` = '"+str(row[0])+"'"
        cursor.execute(select_media)
        media_result = cursor.fetchall()
        image_count = 0
        for media in media_result:
            #print(media)
            if media[2]==2:
                quote['video'] = media[3]
            else:
                image_count +=1
                quote['image'+str(image_count)] = media[3]


        # attribute
        select_attribute = "SELECT * FROM `attribute_value` WHERE `product_id` = '"+str(row[0])+"'"
        cursor.execute(select_attribute)
        attribute_result = cursor.fetchall()
        for attribute in attribute_result:
            select_att = "SELECT * FROM `attribute` WHERE `attribute_id` = '"+str(attribute[2])+"'"
            cursor.execute(select_att)
            att_result = cursor.fetchall()
            image_count = 0
            for att in att_result:
                attribu = att[2]
            #print(attribute)
            quote[attribu] =attribute[3]
            
            attri.append(attribu)
            
            



        quotes.append(quote) 
        attri_res = []
        [attri_res.append(x) for x in attri if x not in attri_res]
        #attri_res = [*set(attri)]
    #print(attri)
    
    with open(filename, 'a', newline='') as f: 
        #w = csv.DictWriter(f,['product_id','gender','category_id','brand_id','group_id','default_shape','sizes','name','metal_color','sku','desp','short','discount','cost_price','price','sale_price','enable_ecommerce','enable_engraving','variant_id','status','slug','meta_title','meta_keywords','meta_desp','updated_at','shopify_variant_id','original_price','sale_price_original']) 
        w = csv.DictWriter(f,attri_res) 
        w.writeheader() 
        for quote in quotes: 
            w.writerow(quote)  
        
        
    print('------------------------------------------')
    print('Processed all records.')

process_data()
import mysql.connector
connection = mysql.connector.connect(host='localhost',
                                         database='showcase_engaagement',
                                         user='proot',
                                         password='php#2020@wEbnEt')

if connection.is_connected():
    db_Info = connection.get_server_info()
    print("Connected to MySQL Server version ", db_Info)
    cursor = connection.cursor()
    cursor.execute("select database();")
    record = cursor.fetchone()
    print("You're connected to database: ", record)


def download_video_data():

    sql_select_Query = "SELECT product_id,shape FROM `products` WHERE `category_id` = 2 AND `brand_id` = 1"
    cursor = connection.cursor()
    cursor.execute(sql_select_Query)
    # get all records
    records = cursor.fetchall()
    print("Total number of rows in table: ", cursor.rowcount)
    count=0
    for row in records:
        count += 1
        print(count)
        product_id = row[0]
        shape = row[1]
        print(product_id)
        print(shape)
            
        insert_media = "INSERT INTO attribute_value (product_id,value, attribute_id,status) VALUES (%s,%s, %s, %s)"
        media_val = (product_id, shape, 12,1)
        cursor.execute(insert_media, media_val)
        connection.commit()      
        print( "inserted!\n") 

download_video_data()
